package aaa.Mavenproject.Service;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import aaa.Mavenproject.Flight;
import aaa.Mavenproject.Places;

public class ServideDao {
	public Flight getFlight(Flight flight){
		Flight f=null;
		try{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("pu");
		EntityManager em=emf.createEntityManager();
		f=em.find(Flight.class, flight.getFlight_id());
		
		
		
	}
		
		catch(Exception e){
			System.out.println(e);
			
		}
		return f;
	
		
	}
		
	
	
	public boolean addFlight(Flight flight){
		boolean result=false;
		try{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("pu");
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(flight);
		em.getTransaction().commit();
		result=true;
	}
		
		catch(Exception e){
			System.out.println(e);
			
		}
		return result;
	
		
	}
		
	
	
	
	
	
	
	public boolean addPlace(Places place){
		boolean result=false;
		try{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("pu");
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(place);
		em.getTransaction().commit();
		result=true;
	}
		
		catch(Exception e){
			System.out.println(e);
			
		}
		return result;
	
		
	}
	public Places  getPlace(Places place){
		Places p=null;
		try{
			EntityManagerFactory emf=Persistence.createEntityManagerFactory("pu");
			EntityManager em=emf.createEntityManager();
			p=em.find(Places.class, place.getPlaceid());
		}
		catch(Exception e){
			System.out.println(e);}
		return p;
		}
		
	}
	


