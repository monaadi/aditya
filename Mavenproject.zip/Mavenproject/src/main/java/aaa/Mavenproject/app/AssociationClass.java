package aaa.Mavenproject.app;

import java.util.List;

import aaa.Mavenproject.Booking;
import aaa.Mavenproject.Flight;
import aaa.Mavenproject.Service.ServideDao;


public class AssociationClass {
public static void main(String[] args) {
	/*Flight flight=new Flight();
	flight.setAirline("indigo");
	flight.setDestination("delhi");
	flight.setFlight_id("12364");
	flight.setSource("mumbai");
	
	Booking book=new Booking();
	book.setAge(5);
	//book.setBooking_id(456);
	book.setBookingdate(new java.util.Date());
	book.setName("nandini");
	book.setNoOfPassengers(5);
	
	Booking book1=new Booking();
	book1.setAge(15);
	//book1.setBooking_id(1456);
	book1.setBookingdate(new java.util.Date());
	book1.setName("nandini1");
	book1.setNoOfPassengers(51);
	
	flight.getBookinglist().add(book);
	flight.getBookinglist().add(book1);	
	boolean result=new ServideDao().addFlight(flight);
	System.out.println(result);*/
	
	Flight ff =new Flight();
	ff.setFlight_id("12364");
	Flight f=new ServideDao().getFlight(ff);
	if(f!=null)
	{
		System.out.printf("\n%20s  %20s", f.getSource(),f.getDestination());
		System.out.printf("\n.....................");
		List<Booking> blist =f.getBookinglist();
		for(Booking b:blist)
			System.out.printf("\n%20s  %20s", b.getName(),b.getAge());
	}
	
	System.exit(0);
}
}
