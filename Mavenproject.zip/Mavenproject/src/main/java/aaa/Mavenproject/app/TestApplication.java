package aaa.Mavenproject.app;

import aaa.Mavenproject.Places;
import aaa.Mavenproject.Service.ServideDao;

public class TestApplication {
	public static void main(String[] args) {
		Places places=new Places();
		places.setLocation("Delhi");
		places.setPlaceid(101);
		places.setPlacename("Red Fort");
boolean flag=new ServideDao().addPlace(places);
System.out.println(flag);
		Places place=new Places();
		place.setPlaceid(101);
		Places p=new ServideDao().getPlace(place);
		if(p==null){
			System.out.println("not found");
		}
		else
		{
			System.out.println("found");
			//System.out.println(place.getPlacename());
		}
		
		
	}

}
