package aaaa.Spring2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import aaaa.Spring2.Controller.StudentController;

/**
 * Hello world!
 *
 */
public class App 
{
	
	private static ApplicationContext applicationContext;
    public static void main( String[] args )
    {
        applicationContext=new ClassPathXmlApplicationContext("Beans.xml");
        StudentController controller=(StudentController)applicationContext.getBean("controllerclass");
       // System.out.println(controller.createStudent());
       // System.out.println(controller.getStudent());
       System.out.println(controller.getAll());
    }
}
