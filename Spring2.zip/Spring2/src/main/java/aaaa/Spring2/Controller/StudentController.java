package aaaa.Spring2.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import aaaa.Spring2.Model.Student;
import aaaa.Spring2.Service.StudentServiceInterface;

@Controller("controllerclass")
public class StudentController {
	@Autowired
	StudentServiceInterface studentservice;
	
	public List<Student> getAll(){
		List<Student> list =studentservice.getAll();
		return list;
	}
	
	
	public boolean createStudent()
	{
		Student student =new Student();
		student.setId("002");
		student.setName("nandini");
		student.setGrade("A");
		boolean flag=studentservice.createStudent(student);
		return flag;
		
	}
	public Student getStudent() {
		
		Student st = studentservice.getStudent("001");
		return st;
	}

}
