package aaaa.Spring2.Dao;

import java.util.List;

import aaaa.Spring2.Model.Student;

public interface StudentDaoInterface {
	public boolean createstudent(Student student); 
	
	public Student getStudent( String id);
	public List<Student> getAll();
	
	

}
