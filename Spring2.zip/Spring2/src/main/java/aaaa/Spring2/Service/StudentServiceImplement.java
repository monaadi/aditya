package aaaa.Spring2.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import aaaa.Spring2.Dao.StudentDaoInterface;
import aaaa.Spring2.Model.Student;

@Service("studentService")
public class StudentServiceImplement implements StudentServiceInterface {
	
	@Autowired
	StudentDaoInterface studentdao;
	
	public boolean  createStudent(Student student)
	{
boolean flag=studentdao.createstudent(student);
return flag;
}
	
	public Student getStudent(String id)
	{
		Student st = studentdao.getStudent(id);
		return st;
}
	
	public List<Student> getAll()
	{
		List<Student> list=studentdao.getAll();
		return list;
	}
}