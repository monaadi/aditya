package aaaa.Spring2.Service;

import java.util.List;

import aaaa.Spring2.Model.Student;

public interface StudentServiceInterface {
	public boolean  createStudent(Student student);
	public Student getStudent(String id);
	public List<Student> getAll();

}
